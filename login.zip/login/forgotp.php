<html>
<head>

    </head>
<body>
<pre>
<?php
$mailaddress = $_POST['mailid'];
$tp='';
echo "\nYour Password has been sent to ";
echo $mailaddress;

$mysqli = new mysqli("localhost","useme","useme123","useme");


if ($mysqli->connect_errno)
{
    echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}

$table="users";
$password = $mysqli->query("SELECT upass FROM users WHERE uemail = '$mailaddress'");


if (!$password)
{
    die('Invalid query: ' . mysql_error());
}
else
{
	while($row = $password->fetch_row())
	{
	echo $row[0];
	$tp=$row[0];
	}



}


$target = 'forgotp.php'; // This is the file that already exists
$link = 'link.html'; // This the filename that you want to link it to


   $to = "$mailaddress";
   $subject = "Forgot Password.";
   //$message = "Click on this link to renew your password http://useme.mituts.com/login/link.html";
   $message = '<html><body>';
   $message .= "<form name=\"forgotpassword\" action=\"http://useme.mituts.com/login/link.php\" method=\"post\"><label for=\"password\">Enter New Password</label><br><input type=\"hidden\" name=\"emailcopy\" value=".$mailaddress."><input type=\"password\" name=\"changepassword\" placeholder=\"new password\" required><input type=\"submit\" value=\"Submit New Password\"></form>";
  // $message .= '<h1>IT works.<h1>';
   $message .='</body></html>';
   $header = "From:admin@viableindia.org \r\n";
   $header .= "MIME-Version: 1.0\r\n";
   $header .= "Content-type: text/html\r\n";
   $retval = mail ($to,$subject,$message,$header);
   if( $retval == true )  
   {
      echo "\n\nMessage sent successfully.";
   }
   else
   {
      echo "\n\nMessage could not be sent.";
   }


$mysqli->close();
?>
</body>
</html>