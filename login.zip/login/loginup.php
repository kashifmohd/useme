<?php
	include 'functions.php';
	if($_POST)
	{
		if(loggedin())
		{
			header('Location: frontpage.php');
			exit();
		}
		$email = $_POST['email'];
		$password = $_POST['password'];
		$username= $_POST['username'];
		$newpassword = $_POST['newpassword'];
		
	
		$mysqli = new mysqli("localhost", "useme", "useme123", "useme");
		if ($mysqli->connect_errno)
		{
			echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
		}

		if($_POST['password'] && $_POST['email'])
		{
			$query="SELECT upass FROM users WHERE uemail='$email'";
			$res= $mysqli->query($query);
			if (!$res)
			{
				die('Invalid query: ' . mysql_error());
			}
			else
			{		
				while($row = $res->fetch_row())
				{
				//if(count($row)>=1)
				//{
					$dbpassword=$row[0];
					if(md5($password)==$dbpassword)
					{
						$loginok= TRUE;
					}
					else
					{
						$loginok= FALSE;
					}
					if($loginok)
					{
					//if($rememberme="ON")
					//	setcookie("email", $email, time()+7200,"/");
					$domain = ($_SERVER['HTTP_HOST'] != 'localhost') ? $_SERVER['HTTP_HOST'] : false;
						
					setcookie("email", $email, time()+7200, '/', $domain, false);
					//else if($rememberme="")
						//$_SESSION['email']==$email;
					header('Location: frontpage.php');
					}
					else
					{
						die("\nIncorrect email-password combination.");
						//die("<html><body><a href="loginup.html">Log In.</a></body></html>");			
					}
				//}
				//else
				//	die("\nAccount does not exist.");
				}
				if(!$row)
					die("\nAccount does not exist.");
			}
		}
		else if($_POST['username'] && $_POST['newpassword'] && $_POST['email'])
		{
			$newpassword=md5($newpassword);
			$query="INSERT INTO users (uname,uemail,upass) VALUES ('$username','$email','$newpassword')";
			$res= $mysqli->query($query);
			if (!$res)
			{
				die('Invalid query: ' . mysql_error());
			}
			else
			{ //echo "Account successfully created. :) Please login to continue.";	
				$loginok=TRUE;
			
				$domain = ($_SERVER['HTTP_HOST'] != 'localhost') ? $_SERVER['HTTP_HOST'] : false;
							
				setcookie("email", $email, time()+7200, '/', $domain, false);
						//else if($rememberme="")
							//$_SESSION['email']==$email;
				header('Location: frontpage.php');
			}
		}
	}
	
?>