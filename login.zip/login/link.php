<html>
<body>
<?php
		
		$changepassword = $_POST['changepassword'];
		$emailcopy = $_POST['emailcopy'];
		//echo $changepassword;
		//echo $emailcopy;
		$mysqli = new mysqli("localhost", "useme", "useme123", "useme");
		if ($mysqli->connect_errno)
		{
			echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
		}
		if($_POST['changepassword'])
		{
			$changepassword=md5($changepassword);
			$query="UPDATE users SET upass='$changepassword' WHERE uemail ='$emailcopy'";
			$res= $mysqli->query($query);
			if (!$res)
			{
				die('Invalid query: ' . mysql_error());
			}
			else
			{ echo "\nPassword changed successfully. Please login to continue.";	
				//header('Location: frontpage.php');
			}
		}
?>
<br>
<a href="loginup.html">Log In</a>
</body>
</html>