<html>
<body>
<?php

include 'functions.php';

if (loggedin()==FALSE)
{
	header('Location: loginup.html');
	exit();  
} 
?>
<p>You are logged in! <p/>
<a href="logout.php">Log Out</a>
</body>
</html>