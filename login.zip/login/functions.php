<?php

session_start();

//connect to database
$mysqli = new mysqli("localhost", "useme", "useme123", "useme");

function loggedin()
{
	if(isset($_COOKIE['email']))
	{
		$loggedin=TRUE;
		return $loggedin;
	}
} 
?>