<?php

session_start();

session_destroy();

setcookie("email","",time()-7200);

header('Location: loginup.html');

?>